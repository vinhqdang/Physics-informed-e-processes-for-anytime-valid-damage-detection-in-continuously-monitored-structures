# PHASE manuscript package (revision)

Manuscript: "Physics-informed e-processes for damage detection under a lifetime
false-alarm budget in continuously monitored structures" (revised title; first submitted
as "Physics-informed e-processes for anytime-valid damage detection in continuously
monitored structures"), submitted to Artificial Intelligence for a
Sustainable Built Environment (special issue: Physics-Informed AI for
Infrastructure Resilience). This folder holds the revised version.

## Layout

```
main.tex, refs.bib          LaTeX source of the revised manuscript (changes shown in blue)
figures/                    ten figures (PNG; Figure 10, KW51, also as vector PDF fig_kw51.pdf)
code/                       simulation, monitors, experiments, Z24 and KW51 pipelines, table generator
revision/                   responses to the reviewers and editor, highlighted and clean PDFs
supplementary/              phase_code.zip: the code archive supplied with the submission (Supplementary file S1)
SUBMISSION_METADATA.txt     title, keywords and file list as they should appear in the submission system
manuscript_anonymised.pdf   double-blind file as first submitted (version 1)
```

## Rebuilding the PDF

Figures are found through `\graphicspath{{figures/}}`, so compile from this
folder. Revised text appears in blue; the clean version has no colour:

    pdflatex main && bibtex main && pdflatex main && pdflatex main
    pdflatex -jobname=main_clean "\def\CLEANBUILD{1}\input{main}"     # clean (run the three-pass sequence)

Revised text is blue (first revision) or red (second revision, responding to the editor); the
clean build has no colour. The responses in `revision/` read their cross-references from the
manuscript: after building `main`, run `cp main.aux revision/` and then, in `revision/`,
`pdflatex response_round2` twice (the first-round letter is `response_to_reviewers`).

## Simulation study (code/)

| File | Role |
|---|---|
| model.py | shear-frame digital twin, environmental driver, damage profiles |
| monitors.py | PHASE, variants (-ND, -C, -R, -E, -BB, -Omega, -S, -NA), comparators |
| twin.py | digital-twin error experiment: monitor built from a perturbed structural model |
| stage.py | Monte Carlo driver, one stage per call; writes part_*.json |
| aggregate.py | reads part_*.json, writes summary.json (counts, exact intervals) and the simulation figures |
| identifiability.py | rank structure, confounded subspace, coherence, nuisance-model sensitivity; writes identifiability.json |
| make_tables.py | generates the LaTeX table bodies (tables/*.tex) from the json files, including Table 3 (both error measures) and the benign-change-then-damage table |
| stiffdam_windows.py | reads part_stiffdam.json (written by `python3 stage.py stiffdam`) and writes stiffdam_windows.json: detection counts for the benign-change-then-damage experiment within nine months of the loss and over the whole remaining record (3,295 epochs, 824 days) |
| schematics.py | draws the pipeline, frame and bridge schematics |
| summary.json | every number reported for the simulation study |

Where Table 3 (accuracy of the first-order model) is computed: stage `geometry` stores both the
normalised error (largest absolute error over largest absolute exact shift, `rel_err`) and the maximum
modal relative error (`max_modal_rel_err`).

Intervals are exact (Clopper-Pearson) and are rounded, not truncated, to two decimals in the tables
(for example 0/100 gives an upper limit of 0.0362, shown as 0.04).

Stages, with fixed seeds: `geometry`, `calib`, `healthy`, `scen0`..`scen6`,
`long`, `long1`, `long2`, `burn120`, `burn240`, `burn480`, `burn720`,
`burn960`, `burn1200`, `burn1460`, `late` (late damage onset), `twin` (digital-twin error), `stiffdam` (benign stiffening then damage), `rate3s`
(trigger rate of the 3-sigma chart), `paths`, for example `python3 stage.py calib`.
Run `geometry` and `calib` first. The full study takes roughly an hour on four
cores. The intermediate part_*.json files are not shipped (summary.json holds
the aggregated results); `stage.py` regenerates them and `aggregate.py` then
rebuilds summary.json and the figures. The stages reproduce the numbers of
version 1 exactly for every monitor that existed there.

Record accounting: 150 calibration + 300 healthy two-year + 300 healthy
four-year + 7 x 150 damage scenarios + 7 x 200 commissioning sweep + 4 x 100
late-onset + 4 x 100 twin-error + 2 x 100 benign-change-then-damage = 4,200 records (3,300 two-year, 900 four-year), plus three records
drawn for the illustrative figure.

## Z24 bridge study (code/)

| File | Role |
|---|---|
| z24_modal.py | frequency domain decomposition and band-limited modal tracking |
| z24_experiment.py | monitors and experiments R1a-R5 |
| z24_run_all.py | reproduces the full Z24 table, both modalities, ten monitors |
| z24_sensitivity.py | chronological, reversed, circular-shift, set-up-shuffle orderings; exchangeability diagnostics; writes z24_sensitivity.json (set `ORDERS=poolblock OUT=z24_pool.json` for the set-up shuffle across commissioning days) |
| z24_figure.py | draws fig_z24.png |
| z24_modal.npz | extracted modal features, ambient vibration (690 epochs) |
| z24_modal_fvt.npz | extracted modal features, forced vibration (711 epochs) |
| z24_full.json | results of z24_run_all.py (200 orderings per experiment) |

Everything in the Z24 section reproduces from the two .npz files:

    cd code && python3 z24_run_all.py        # about 4 minutes

Set `REPS=20` for a quick check.

### Data provenance

The raw Z24 progressive damage test acceleration records are NOT included. They
are KU Leuven research data and must be obtained from KU Leuven. The analysis
used the ambient (avt) and forced (fvt) records for test states 01-10, in
Parquet form. To rebuild the features from raw records, set `ROOT` in
z24_modal.py, delete the .npz files, and run `python3 z24_modal.py`.

## KW51 study (code/)

| File | Role |
|---|---|
| kw51_experiment.py | PHASE (reduced: regression surrogate, orthant cone) and comparators on the KW51 tracked-mode data; `--download` fetches trackedmodes.zip from Zenodo record 3745914 (CC BY-NC-SA 4.0; not redistributed here) |
| kw51_figure.py | draws Figure 10: fig_kw51.pdf (vector, TrueType fonts embedded, 7.0 in wide, all text 8 pt or larger at that size) and a PNG preview |
| kw51_results.json | all 180 commissioning configurations (2 epoch lengths x 6 surrogates x 15 windows) and the evidence paths of the plotted configurations |

    cd code && python3 kw51_experiment.py --download && python3 kw51_experiment.py   # about 3 minutes

### Interpretation caveats (also stated in the paper, Section 5)

- The released files carry no environmental covariate, so the surrogate reduces
  to a running intercept and the identifiability analysis cannot be exercised.
- Each structural state was measured on a different day; the two undamaged
  references differ by 0.9-1.4% in tracked frequencies, comparable to the damage
  signatures. Experiment R5 shows a nominally undamaged new day also alarms
  when commissioning epochs from the two reference days are mixed. R2 and R4
  therefore show a response to real change that depends on how commissioning
  data are ordered (z24_sensitivity.py), not calibrated separation of damage
  from environment. The recovery experiment R3 is insensitive to ordering.
- Only three modes were tracked consistently across all ten states.

## Figures

All ten figures are the authors' own work (three schematics and seven plots from
the experiments); no third-party imagery is used. The figure environment for the
bridge in main.tex contains a commented-out two-panel block for photographs, if
rights are later cleared (e.g. Reynders and De Roeck, 2009, DOI
10.1002/9780470061626.shm165). Emerald requires non-exclusive, worldwide, print
and electronic rights for the life of the work.

## Availability

The archive `supplementary/phase_code.zip` (Supplementary file S1 of the submission) contains `code/`,
`figures/fig_kw51.pdf` and this file. The same material is the content of this repository. The raw Z24
records and the KW51 tracked-mode file are not redistributed (see Data provenance).

## Environment

Python 3, numpy, scipy, pandas, matplotlib, pyarrow (only to read raw Z24
Parquet). No GPU or network needed once the .npz files are present.
