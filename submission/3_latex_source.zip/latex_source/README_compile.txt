LaTeX source of the revised manuscript (AISBE-08-2026-0041.R2)
Files: main.tex, refs.bib, main.bbl (pre-built bibliography), figures/ (ten figures; Figure 10 = fig_kw51.pdf, vector)
Compile (pdfLaTeX, run from this folder):
  pdflatex main && bibtex main && pdflatex main && pdflatex main      -> highlighted version (blue = round 1, red = round 2)
  pdflatex -jobname=main_clean "\def\CLEANBUILD{1}\input{main}"       -> clean version (repeat with bibtex as above)
Packages used: amsmath, amssymb, amsthm, graphicx, booktabs, setspace, natbib, caption, hyperref, algorithm, algpseudocode, xcolor, array.
